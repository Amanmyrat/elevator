<p>
    <?= __('This log displays a list of successful sign in attempts by administrators. Records are kept for a total of :days days.', ['days' => 60]) ?>
</p>
