<div class="padded-container container-flush">
    <?= $this->makeHintPartial('backend_accesslogs_hint', 'hint') ?>
</div>

<?= $this->listRender() ?>
