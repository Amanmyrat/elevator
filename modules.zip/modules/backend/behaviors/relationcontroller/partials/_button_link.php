<a
    data-control="popup"
    data-handler="onRelationButtonLink"
    href="javascript:;"
    class="btn btn-sm btn-secondary relation-button-link"
>
    <i class="icon-link"></i> <?= e($this->relationGetMessage('buttonLink')) ?>
</a>
