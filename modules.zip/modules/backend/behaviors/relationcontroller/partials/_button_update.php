<a
    data-control="popup"
    data-handler="onRelationButtonUpdate"
    data-request-data="manage_id: '<?= $relationManageId ?>'"
    href="javascript:;"
    class="btn btn-sm btn-secondary relation-button-update"
>
    <i class="icon-settings"></i> <?= e($this->relationGetMessage('buttonUpdate')) ?>
</a>
