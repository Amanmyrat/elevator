<?php if ($toolbar): ?>
    <?= $toolbar->render() ?>
<?php endif ?>

<div class="list-widget-container">
    <?php if ($filter): ?>
        <?= $filter->render() ?>
    <?php endif ?>

    <?= $list->render() ?>
</div>
